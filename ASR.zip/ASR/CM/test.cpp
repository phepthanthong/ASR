#include <iostream>
using namespace std;

int main () {
  string c="con cá Lam, xe Lam.";
  cout << c << endl;
}
