#include <iostream>
#include <math.h>
#include <cstdlib>
using namespace std;

int main () {
  cout << "Hello World" << endl;
  cout << "LOL" << endl;
}
